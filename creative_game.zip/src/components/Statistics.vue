<template>
   
<!-- Statistics Section -->
            <section class="section statistics-section">
                <div class="container">
                    <div class="row">
                        <div class="col-12 col-md-4">
                            <div class="statistics-list text-center">
                                <span>500+</span>
                                <h3>Happy Clients</h3>
                            </div>
                        </div>
                        <div class="col-12 col-md-4">
                            <div class="statistics-list text-center">
                                <span>120+</span>
                                <h3>Online Appointments</h3>
                            </div>
                        </div>
                        <div class="col-12 col-md-4">
                            <div class="statistics-list text-center">
                                <span>100%</span>
                                <h3>Job Satisfaction</h3>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
            <!-- /Statistics Section -->


</template>