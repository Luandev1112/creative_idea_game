<template>
    
    <!-- Path section start -->
			<section class="section path-section">
				<div class="section-header text-center">
					<div class="container">
						<span>Choose the</span>
						<h2>Different All Learning Paths</h2>
						<p class="sub-title">Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt</p>
					</div>
				</div>
				<div class="learning-path-col">
					<div class="container">
						<div class="row">
							<div class="col-12 col-md-4 col-lg-3">
								<div class="large-col">
									<router-link to="/mentee/mentor-search" class="large-col-image">
										<div class="image-col-merge">
											<img src="../assets/images/path-img1.jpg" alt="">
											<div class="text-col">
												<h5>Digital Marketer</h5>
											</div>
										</div>
									</router-link>
								</div>
							</div>
							<div class="col-12 col-md-4 col-lg-3">
								<div class="large-col">
									<router-link to="/mentee/mentor-search" class="large-col-image">
										<div class="image-col-merge">
											<img src="../assets/images/path-img2.jpg" alt="">
											<div class="text-col">
												<h5>Ui designer</h5>
											</div>
										</div>
									</router-link>
								</div>
							</div>
							<div class="col-12 col-md-4 col-lg-3">
								<div class="large-col">
									<router-link to="/mentee/mentor-search" class="large-col-image">
										<div class="image-col-merge">
											<img src="../assets/images/path-img3.jpg" alt="">
											<div class="text-col">
												<h5>IT Security</h5>
											</div>
										</div>
									</router-link>
								</div>
							</div>
							<div class="col-12 col-md-4 col-lg-3">
								<div class="large-col">
									<router-link to="/mentee/mentor-search" class="large-col-image">
										<div class="image-col-merge">
											<img src="../assets/images/path-img4.jpg" alt="">
											<div class="text-col">
												<h5>Front-End Developer</h5>
											</div>
										</div>
									</router-link>
								</div>
							</div>
							<div class="col-12 col-md-4 col-lg-3">
								<div class="large-col">
									<router-link to="/mentee/mentor-search" class="large-col-image">
										<div class="image-col-merge">
											<img src="../assets/images/path-img5.jpg" alt="">
											<div class="text-col">
												<h5>Web Developer</h5>
											</div>
										</div>
									</router-link>
								</div>
							</div>
							<div class="col-12 col-md-4 col-lg-3">
								<div class="large-col">
									<router-link to="/mentee/mentor-search" class="large-col-image">
										<div class="image-col-merge">
											<img src="../assets/images/path-img6.jpg" alt="">
											<div class="text-col">
												<h5>Administrator</h5>
											</div>
										</div>
									</router-link>
								</div>
							</div>
							<div class="col-12 col-md-4 col-lg-3">
								<div class="large-col">
									<router-link to="/mentee/mentor-search" class="large-col-image">
										<div class="image-col-merge">
											<img src="../assets/images/path-img7.jpg" alt="">
											<div class="text-col">
												<h5>Project Manager</h5>
											</div>
										</div>
									</router-link>
								</div>
							</div>
							<div class="col-12 col-md-4 col-lg-3">
								<div class="large-col">
									<router-link to="/mentee/mentor-search" class="large-col-image">
										<div class="image-col-merge">
											<img src="../assets/images/path-img8.jpg" alt="">
											<div class="text-col">
												<h5>PHP Developer</h5>
											</div>
										</div>
									</router-link>
								</div>
							</div>
						</div>
						<div class="view-all text-center"><a href="#" class="btn btn-primary">View All</a></div>						
					</div>
				</div>
			</section>
			<!-- Path section end -->

</template>