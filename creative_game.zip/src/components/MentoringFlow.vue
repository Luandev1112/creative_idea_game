<template>
  <section class="section how-it-works">
    <div class="container">
      <div class="section-header text-center">
        <h2>Round 1</h2>
        <p class="sub-title">3/5</p>
      </div>
      <div class="row">
        <div class="col-12 col-md-8 col-lg-8 col-lg-offset-2">
          <div class="progress-bar-custom">
            <h6>Complete your profiles</h6>
            <div class="pro-progress">
              <div class="tooltip-toggle" tabindex="0"></div>
              <div class="tooltip">3.7</div>
            </div>
          </div>
        </div>
        <div class="col-12 col-md-8 col-lg-8 col-lg-offset-2">
          <div class="progress-bar-custom">
            <h6>Complete your profiles</h6>
            <div class="pro-progress">
              <div class="tooltip-toggle" tabindex="0"></div>
              <div class="tooltip">2.6</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
</template>
